package main;

import clases.Alumno;
import java.io.*; //importar
import java.io.InputStreamReader;

public class Main {

    //Declaracion de Arreglo
    static Alumno alumnos[] = null;

    //Contador
    static int cont = 0;

    //Lectura y captura del teclado reemplaza a la funcion Scanner
    static InputStreamReader isr = new InputStreamReader(System.in);
    static BufferedReader lector = new BufferedReader(isr);

    public static void main(String args[]) throws IOException {

        //Inicializar arreglo
        alumnos = new Alumno[5];

        //inicializar opcion
        int opcion = 0;

        //Menu
        do {
            System.out.println("MENU DE CONTROL");
            System.out.println("----------------");
            System.out.println("1.-Inrgesar alumno");
            System.out.println("2.-Buscar alumno");
            System.out.println("3.-Listar alumno");
            System.out.println("4.-Salir");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(lector.readLine());//capturamos lo ingresado

            switch (opcion) {
                case 1:
                    if (cont < 5) {
                        agregarAlumno();
                    } else {
                        System.out.println("No hay cupos");
                    }
                    break;
                case 2:
                    editarAlumno();
                    break;
                case 3:
                    listarAlumno();
                    break;
                case 4:
                    System.out.println("Saliendo...");
            }
        } while (opcion != 4);
        System.exit(0);
    }

    //Metodo crear alumno
    private static void agregarAlumno() throws IOException {

        //variables locales
        String rut = "";
        String nombre = "";
        String asignatura = "";
        String estado = "";
        double n1 = 0;
        double n2 = 0;
        double n3 = 0;
        double promedio = 0;

        //Lectura de datos:
        System.out.println("\n\n\n");
        System.out.println("--------------------");
        System.out.println("DATOS DE ALUMNO");
        System.out.println("--------------------");

        System.out.print("Rut: ");
        rut = lector.readLine();

        System.out.print("Nombre: ");
        nombre = lector.readLine();

        System.out.print("Asignaura: ");
        asignatura = lector.readLine();

        System.out.print("Nota 1: ");
        n1 = Double.parseDouble(lector.readLine());//se convierte el dato de string a double

        System.out.print("Nota 2: ");
        n2 = Double.parseDouble(lector.readLine());

        System.out.print("Nota 3: ");
        n3 = Double.parseDouble(lector.readLine());

        //REALIZAR CALCULOS:
        promedio = (n1 + n2 + n3) / 3;

        //MUESTRA DE DATOS:
        System.out.print("Promedio de notas: " + promedio);

        //CONDICIONES:
        if (promedio >= 3.95) {
            estado = "Aprobado";
            System.out.println(estado);
        } else {
            estado = "Reprobado";
            System.out.println(estado);
        }

        //Agregar elementos a la coleccion:
        alumnos[cont] = new Alumno(rut, nombre, asignatura, estado, n1, n2, n3, promedio);
        cont++;
        System.out.println("Alumno agregado!: " + cont);
    }

    //metodo editar alumno
    private static void editarAlumno() throws IOException {

        //vairables locales
        String rut;
        int pos = -1;
        int accion = 0;
        System.out.print("Ingrese Rut: ");
        rut = lector.readLine();
        pos = buscarAlumno(rut);

        if (pos >= 0) {
            System.out.println("Datos: " + alumnos[pos].toString());
            System.out.println("1.-Modificar");
            System.out.println("2.-Eliminar");
            System.out.println("Ingrese opción: ");
            accion = Integer.parseInt(lector.readLine());

            switch (accion) {
                case 1:
                    modificarDatos(pos);
                    break;
                case 2:
                    eliminarDatos(pos);
                    break;
                default:
                    System.out.println("Opción inválida!");
            }
        } else {
            System.out.println("No existe registro!");
        }
    }

    //metodo buscarAlumno
    private static int buscarAlumno(String rut) {
        int pos = -1;
        for (int i = 0; i < cont; i++) {
            if (alumnos[i].getRut().equals(rut)) {
                System.out.println("Registro encontrado!");
                pos = i;
            } else {
                System.out.println("Registro inexistente!");
            }
        }
        return pos;
    }

    //metodo modificarDatos
    public static void modificarDatos(int pos) throws IOException {

        //variables locales:
        String nombre = null;
        String asignatura = null;
        String estado = null;
        double n1 = 0;
        double n2 = 0;
        double n3 = 0;
        double promedio = 0;
        int opcion = 0;
        int seguir = 0;

        //Condiciones:
        while (seguir == 1) {
            System.out.println("1.-Modificar nombre?");
            System.out.println("2.-Modificar asignatura?");
            System.out.println("3.-Modificar nota1?");
            System.out.println("4.-Modificar nota2?");
            System.out.println("5.-Modificar nota3?");
            System.out.print("Ingrese opción: ");
            opcion = Integer.parseInt(lector.readLine());

            //Manejo de condiciones:
            switch (opcion) {
                case 1:
                    System.out.println("Nombre: ");
                    nombre = lector.readLine();
                    alumnos[pos].setNombre(nombre);
                    break;
                case 2:
                    System.out.println("Asignatura: ");
                    asignatura = lector.readLine();
                    alumnos[pos].setAsignatura(asignatura);
                    break;
                case 3:
                    System.out.println("Nota 1: ");
                    n1 = Double.parseDouble(lector.readLine());
                    alumnos[pos].setN1(n1);
                    break;
                case 4:
                    System.out.println("Nota 2: ");
                    n2 = Double.parseDouble(lector.readLine());
                    alumnos[pos].setN2(n2);
                    break;
                case 5:
                    System.out.println("Nota 3: ");
                    n3 = Double.parseDouble(lector.readLine());
                    alumnos[pos].setN3(n3);
                    break;
            }

            if (opcion >= 3 && opcion <= 5) {
                n1 = alumnos[pos].getN1();
                n2 = alumnos[pos].getN2();
                n3 = alumnos[pos].getN3();
                promedio = (n1 + n2 + n3) / 3;
                System.out.println("Promedio de notas: " + promedio);
                alumnos[pos].setPromedio(promedio);

                if (promedio >= 3.95) {
                    estado = "Aprobado";
                    System.out.println(estado);
                } else {
                    estado = "Reporbado";
                    System.out.println(estado);
                }
                alumnos[pos].setEstado(estado);
            }
            System.out.println("--------------------");
            System.out.println("1.-Segir");
            System.out.println("2.-Salir");
            System.out.print("Ingrese opción: ");
            seguir = Integer.parseInt(lector.readLine());
        }
    }

    //metodo eliminarDatos
    public static void eliminarDatos(int pos) {
        for (int i = pos; i < cont; i++) {
            alumnos[i] = alumnos[i + 1];
        }
        System.out.println("Registro eliminado!");
        cont--;
    }

    //Metodo listar alumno
    private static void listarAlumno() {
        for (int i = 0; i < cont; i++) {
            System.out.println("\n\n--ALUMNOS REGISTRADOS--");
            System.out.println("" + alumnos[i].toString());
        }
    }
}
