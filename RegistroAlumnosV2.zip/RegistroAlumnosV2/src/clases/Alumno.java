package clases;

public class Alumno {

    //1.-ATRIBUTOS
    private String rut;
    private String nombre;
    private String asignatura;
    private String estado;
    private double n1;
    private double n2;
    private double n3;
    private double promedio;

    //2.-CONSTRUCTORES
    public Alumno() {
    }

    public Alumno(String rut, String nombre, String asignatura, String estado, double n1, double n2, double n3, double promedio) {
        this.rut = rut;
        this.nombre = nombre;
        this.asignatura = asignatura;
        this.estado = estado;
        this.n1 = n1;
        this.n2 = n2;
        this.n3 = n3;
        this.promedio = promedio;
    }

    //3.-GETTERS
    public String getRut() {
        return rut;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public String getEstado() {
        return estado;
    }

    public double getN1() {
        return n1;
    }

    public double getN2() {
        return n2;
    }

    public double getN3() {
        return n3;
    }

    public double getPromedio() {
        return promedio;
    }

    //4.-SETTERS
    public void setRut(String rut) {
        this.rut = rut;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setN1(double n1) {
        this.n1 = n1;
    }

    public void setN2(double n2) {
        this.n2 = n2;
    }

    public void setN3(double n3) {
        this.n3 = n3;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    //5.-LISTADO DE ATRIBUTOS
    @Override
    public String toString() {
        return "Alumno{" + "rut=" + rut + ", nombre=" + nombre + ", asignatura=" + asignatura + ", estado=" + estado + ", n1=" + n1 + ", n2=" + n2 + ", n3=" + n3 + ", promedio=" + promedio + '}';
    }
}
